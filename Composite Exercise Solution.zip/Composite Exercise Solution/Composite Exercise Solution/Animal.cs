﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Composite_Exercise_Solution
{
    public interface Animal
    {
        void ShowDetails();
    }
}
