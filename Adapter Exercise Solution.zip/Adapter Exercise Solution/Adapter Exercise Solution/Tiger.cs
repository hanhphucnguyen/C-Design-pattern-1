﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adapter_Exercise_Solution
{
    public class Tiger
    {
        public void roar()
        {
            Console.WriteLine("Roar!");
        }
    }
}
