﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bridge_Exercise_Solution
{
    public class RedCircle : DrawAPI
    {
        public void DrawCircle()
        {
            Console.WriteLine("Drawing a red circle");
        }
    }
}
