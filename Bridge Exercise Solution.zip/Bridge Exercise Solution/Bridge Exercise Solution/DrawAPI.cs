﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bridge_Exercise_Solution
{
    public interface DrawAPI
    {
        void DrawCircle();
    }
}
