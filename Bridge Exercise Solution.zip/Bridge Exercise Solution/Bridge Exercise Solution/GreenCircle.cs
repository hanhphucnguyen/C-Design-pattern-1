﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bridge_Exercise_Solution
{
    public class GreenCircle : DrawAPI
    {
        public void DrawCircle()
        {
            Console.WriteLine("Drawing a green circle");
        }
    }
}
