﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Factory_Method
{
    public class Motorcycle : Car
    {
        public Motorcycle()
        {
            Console.WriteLine("Creating a Motorcycle");
        }
    }
}
