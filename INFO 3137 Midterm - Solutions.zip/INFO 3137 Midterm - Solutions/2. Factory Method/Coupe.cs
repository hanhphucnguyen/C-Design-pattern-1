﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2.Factory_Method
{
    public class Coupe : Car
    {
        public Coupe()
        {
            Console.WriteLine("Creating a Coupe");
        }
    }
}
