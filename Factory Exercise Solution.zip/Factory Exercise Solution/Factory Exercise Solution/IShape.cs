﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Factory_Exercise_Solution
{
    public interface IShape
    {
        void draw();
    }
}
