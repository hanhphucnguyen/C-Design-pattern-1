﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Decorator_Exercise_Solution
{
    public interface iAnimal
    {
        void printAnimal();
    }
}
