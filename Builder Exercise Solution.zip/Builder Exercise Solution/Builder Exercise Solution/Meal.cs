﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Builder_Exercise_Solution
{
    //This class is the product
    public class Meal
    {
        public string main;
        public string toy;
        public string side;
        public string drink;
    }
}
